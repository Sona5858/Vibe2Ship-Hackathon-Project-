# DeadlineOS – The AI Execution Agent

DeadlineOS is a production-ready, hackathon-quality AI execution assistant designed to help users complete their tasks before deadlines. Rather than functioning as a passive todo app, it serves as an agentic partner that handles planning, priority scoring, automated daily scheduling around calendar availability, notification routing, and productivity coaching.

---

## ⚡ Tech Stack
- **Frontend**: React (Vite) + Tailwind CSS v4 + Framer Motion (premium animations) + Recharts (completion metrics).
- **Backend**: Node.js + Express.
- **Database & Auth**: Firebase Auth (Google Client login) + Firestore.
- **Integrations**: Gemini 2.5 Flash API + Google Calendar API.
- **Deployment**: Google Cloud Run (Backend) + Firebase Hosting (Frontend) + Cloud Scheduler + Google Secret Manager.

---

## 📁 Folder Structure
```
DeadlineOS/
├── backend/
│   ├── src/
│   │   ├── config/          # Firebase Admin SDK, Gemini client, OAuth configs
│   │   ├── controllers/     # Route controller logic
│   │   ├── middleware/      # Firebase Auth Token verifications
│   │   ├── routes/          # REST Endpoint routes mapping
│   │   ├── utils/           # Gemini Prompts and helper algorithms
│   │   ├── app.js           # Express app setup
│   │   └── server.js        # Listener bootstrap
│   ├── Dockerfile           # Production container definition
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── components/      # Navigation, Uploads, Timelines, Charts
│   │   ├── context/         # Auth session provider
│   │   ├── pages/           # Dashboard, Tasks, Schedules, Settings views
│   │   ├── services/        # Axios API and Firebase SDK initializations
│   │   ├── App.jsx          # Route container configuration
│   │   ├── index.css        # Tailwind v4 import & custom styles
│   │   └── main.jsx         # Render bootstrap
│   ├── index.html           # Document template with custom fonts
│   ├── vite.config.js       # Vite configuration with Tailwind CSS plugin
│   └── package.json
├── firebase.json            # Firebase CLI hosting and emulator bindings
├── firestore.rules          # Firestore sandboxed database security rules
├── firestore.indexes.json   # Single-field indexing configurations
├── docker-compose.yml       # Local multi-container development configuration
└── README.md
```

---

## ⚙️ Local Setup Guide

### 1. Prerequisites
- [Node.js v20+](https://nodejs.org/) installed.
- A [Firebase Project](https://console.firebase.google.com/) configured with **Firestore** and **Google Authentication** enabled.
- A [Google Cloud Console Project](https://console.cloud.google.com/) with **Gemini API** and **Google Calendar API** enabled.

### 2. Google OAuth Credentials Configuration
To connect Google Calendar sync, you need OAuth client credentials:
1. In the **Google Cloud Console**, go to **APIs & Services > Credentials**.
2. Click **Create Credentials** and select **OAuth client ID**.
3. Choose **Web application** as application type.
4. Set Authorized Redirect URIs to include:
   - `http://localhost:5173/settings` (for local development)
   - `https://your-firebase-app.web.app/settings` (for production)
5. Save the **Client ID** and **Client Secret**.

### 3. Backend Setup
1. Navigate to `/backend`:
   ```bash
   cd backend
   ```
2. Create your `.env` file:
   ```bash
   cp .env.example .env
   ```
3. Populate the variables inside `.env`:
   - `FIREBASE_PROJECT_ID`: Your Firebase project ID.
   - `GEMINI_API_KEY`: Your Gemini 2.5 Flash API Key.
   - `GOOGLE_CLIENT_ID`: Your Google OAuth Client ID.
   - `GOOGLE_CLIENT_SECRET`: Your Google OAuth Client Secret.
4. Install dependencies:
   ```bash
   npm install
   ```
5. Run the dev server:
   ```bash
   npm run dev
   ```
   *The backend will boot up at `http://localhost:5000`.*

### 4. Frontend Setup
1. Navigate to `/frontend`:
   ```bash
   cd ../frontend
   ```
2. Create your `.env` file:
   ```bash
   cp .env.example .env
   ```
3. Populate the variables inside `.env`:
   - `VITE_FIREBASE_API_KEY`: Your Firebase project API key.
   - `VITE_FIREBASE_AUTH_DOMAIN`: `<your-project-id>.firebaseapp.com`
   - `VITE_FIREBASE_PROJECT_ID`: Your Firebase project ID.
   - `VITE_GOOGLE_CLIENT_ID`: Your Google OAuth Client ID.
4. Install dependencies:
   ```bash
   npm install
   ```
5. Boot up the Vite hot-reloading server:
   ```bash
   npm run dev
   ```
   *The client will open automatically at `http://localhost:5173`.*

---

## 🚀 Deployment Guide

### Deploy Backend to Google Cloud Run

[![Run on Google Cloud](https://deploy.cloud.run/button.svg)](https://deploy.cloud.run/?dir=backend)

> [!TIP]
> You can deploy this backend instantly using the **Cloud Run Deploy Button** above! Once you push this codebase to your own GitHub repository, clicking this button in your GitHub README will automatically clone the repository, build the Docker container using our `backend/Dockerfile`, prompt you for the required environment variables (configured via `backend/app.json`), and deploy it to Google Cloud Run.
>
> Alternatively, to deploy manually using the CLI:

1. Authenticate with Google Cloud CLI:

   ```bash
   gcloud auth login
   ```
2. Configure your project:
   ```bash
   gcloud config set project YOUR_PROJECT_ID
   ```
3. Submit and build the container in Google Artifact Registry:
   ```bash
   gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/deadlineos-backend ./backend
   ```
4. Deploy the container to Cloud Run:
   ```bash
   gcloud run deploy deadlineos-backend \
     --image gcr.io/YOUR_PROJECT_ID/deadlineos-backend \
     --platform managed \
     --allow-unauthenticated \
     --set-env-vars="GEMINI_API_KEY=YOUR_KEY,GOOGLE_CLIENT_ID=YOUR_CLIENT,GOOGLE_CLIENT_SECRET=YOUR_SECRET"
   ```
5. Capture the service URL returned by Cloud Run.

### Deploy Frontend to Firebase Hosting
1. Update `frontend/.env` to point the `VITE_API_URL` to your Cloud Run service URL:
   ```env
   VITE_API_URL=https://deadlineos-backend-xxxxxx.a.run.app/api
   ```
2. Run build inside `/frontend` to package assets:
   ```bash
   npm run build
   ```
3. Deploy the compiled bundles:
   ```bash
   firebase deploy --only hosting
   ```

---

## 🔒 Security & Firestore Rules
Database sandboxing is enforced through `firestore.rules`. Ensure you push the rules to your live project:
```bash
firebase deploy --only firestore:rules
```
This restricts cross-user read/write queries, keeping credentials and calendar tokens securely sandbox-locked to the authenticated user's scope.
