import React, { useState, useEffect } from 'react';
import api from '../services/api.js';
import ScheduleTimeline from '../components/ScheduleTimeline.jsx';
import { Calendar, Loader2 } from 'lucide-react';

const Schedule = () => {
  const [schedule, setSchedule] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const dateStr = new Date().toISOString().split('T')[0];

  const fetchSchedule = async () => {
    try {
      const res = await api.get(`/schedules/${dateStr}`);
      setSchedule(res.data);
    } catch (err) {
      if (err.response && err.response.status === 404) {
        setSchedule(null);
      } else {
        console.error("Error fetching schedule:", err);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSchedule();
  }, []);

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const res = await api.post('/schedules/generate', { date: dateStr });
      setSchedule(res.data);
    } catch (err) {
      console.error(err);
      alert("Failed to generate schedule. Check if you have tasks.");
    } finally {
      setGenerating(false);
    }
  };

  const handleStatusUpdate = async (blockId, status, taskId) => {
    try {
      if (taskId) {
        await api.patch(`/tasks/${taskId}`, { status });
      }

      if (status === 'skipped') {
        const now = new Date();
        const HH = String(now.getHours()).padStart(2, '0');
        const MM = String(now.getMinutes()).padStart(2, '0');
        const currentTime = `${HH}:${MM}`;
        
        const res = await api.post('/schedules/replan', { date: dateStr, currentTime });
        setSchedule(res.data);
      } else {
        const res = await api.patch(`/schedules/${dateStr}/blocks/${blockId}`, { status });
        setSchedule(res.data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleReplan = async () => {
    try {
      const now = new Date();
      const HH = String(now.getHours()).padStart(2, '0');
      const MM = String(now.getMinutes()).padStart(2, '0');
      const currentTime = `${HH}:${MM}`;
      
      const res = await api.post('/schedules/replan', { date: dateStr, currentTime });
      setSchedule(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleCalendarSync = async () => {
    try {
      await api.post('/schedules/sync-calendar', { date: dateStr });
      await fetchSchedule();
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.error || "Google Calendar sync failed.");
    }
  };

  return (
    <div className="pl-72 pr-8 py-8 min-h-screen relative">
      <div className="bg-mesh" />

      <div className="flex items-center gap-3 mb-8">
        <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 neon-glow-primary">
          <Calendar className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-2xl font-black text-slate-100 tracking-wider">SCHEDULE</h1>
          <p className="text-xs text-slate-500 font-semibold uppercase tracking-widest mt-0.5">Plan and execute daily schedule blocks</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64 text-slate-500">
          Loading schedule...
        </div>
      ) : schedule ? (
        <div className="max-w-3xl">
          <ScheduleTimeline
            schedule={schedule}
            onStatusUpdate={handleStatusUpdate}
            onReplan={handleReplan}
            onCalendarSync={handleCalendarSync}
          />
        </div>
      ) : (
        <div className="max-w-md mx-auto glass-panel p-8 rounded-3xl border border-slate-800 text-center space-y-6 mt-12">
          <div className="flex justify-center">
            <div className="p-4 rounded-full bg-slate-900 border border-slate-800">
              <Calendar className="h-10 w-10 text-slate-400" />
            </div>
          </div>
          <h3 className="text-lg font-bold text-slate-200">No schedule generated for today</h3>
          <p className="text-sm text-slate-500">
            Let our AI agent parse your active tasks, block busy Google Calendar slots, and create a custom focus schedule.
          </p>
          <button
            onClick={handleGenerate}
            disabled={generating}
            className="w-full py-3 bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-800/40 text-slate-950 font-bold text-sm rounded-xl smooth-transition shadow-lg flex items-center justify-center gap-2 cursor-pointer"
          >
            {generating ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Generating Agenda...
              </>
            ) : (
              "Generate Today's Schedule"
            )}
          </button>
        </div>
      )}
    </div>
  );
};

export default Schedule;
