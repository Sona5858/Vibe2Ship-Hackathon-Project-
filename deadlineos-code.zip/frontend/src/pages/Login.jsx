import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { Zap, ShieldCheck, CalendarRange, BrainCircuit } from 'lucide-react';

const Login = () => {
  const { currentUser, loginWithGoogle } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (currentUser) {
      navigate('/dashboard');
    }
  }, [currentUser, navigate]);

  const handleLogin = async () => {
    try {
      await loginWithGoogle();
      navigate('/dashboard');
    } catch (error) {
      console.error('Google login failed:', error);
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center p-4 bg-[#070a0f] overflow-hidden">
      <div className="absolute top-1/4 left-1/4 h-72 w-72 rounded-full bg-violet-600/10 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 h-72 w-72 rounded-full bg-emerald-600/10 blur-[120px] pointer-events-none" />

      <div className="glass-panel max-w-md w-full p-8 rounded-3xl border border-slate-800/80 shadow-2xl relative z-10 text-center space-y-8 neon-glow-primary">
        <div className="flex justify-center">
          <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 neon-glow-primary animate-pulse">
            <Zap className="h-10 w-10" />
          </div>
        </div>

        <div>
          <h2 className="text-3xl font-extrabold text-slate-100 tracking-wider font-sans">
            Deadline<span className="text-emerald-400">OS</span>
          </h2>
          <p className="text-xs text-slate-500 uppercase tracking-widest font-bold mt-1">The AI Execution Agent</p>
        </div>

        <div className="space-y-4 text-left border-y border-slate-900 py-6">
          <div className="flex gap-3">
            <BrainCircuit className="h-5 w-5 text-violet-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-slate-200">AI Task & Priority Scoring</h4>
              <p className="text-xs text-slate-450 mt-0.5">Extract tasks from voice or syllabus images, scoring them instantly.</p>
            </div>
          </div>
          <div className="flex gap-3">
            <CalendarRange className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-slate-200">Google Calendar Sync</h4>
              <p className="text-xs text-slate-450 mt-0.5">Avoid calendar block conflicts and push focus hours dynamically.</p>
            </div>
          </div>
          <div className="flex gap-3">
            <ShieldCheck className="h-5 w-5 text-blue-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-slate-200">Context-Aware Coaching</h4>
              <p className="text-xs text-slate-450 mt-0.5">Get dynamic alerts and customized coaching guides automatically.</p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <button
            onClick={handleLogin}
            className="w-full flex items-center justify-center gap-3 py-3 px-4 bg-emerald-500 hover:bg-emerald-600 active:scale-[0.98] text-slate-950 font-bold rounded-xl smooth-transition shadow-lg cursor-pointer"
          >
            <svg className="h-5 w-5 fill-current" viewBox="0 0 24 24">
              <path d="M12.24 10.285V13.4h6.887C18.2 15.614 15.645 18 12.24 18c-3.86 0-7-3.14-7-7s3.14-7 7-7c1.7 0 3.3.614 4.5 1.734l2.437-2.437C17.3 1.7 14.9 1 12.24 1 6.58 1 2 5.58 2 11.24s4.58 10.24 10.24 10.24c5.795 0 10.254-4.074 10.254-10.24 0-.695-.08-1.355-.22-1.955H12.24z"/>
            </svg>
            Sign in with Google
          </button>
          <p className="text-[10px] text-slate-500">Secure authorization verified via Firebase Auth</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
