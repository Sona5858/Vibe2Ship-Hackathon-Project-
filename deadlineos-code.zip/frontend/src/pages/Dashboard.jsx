import React, { useState, useEffect } from 'react';
import api from '../services/api.js';
import DashboardStats from '../components/DashboardStats.jsx';
import { Play, RefreshCw, Sparkles } from 'lucide-react';

const Dashboard = () => {
  const [stats, setStats] = useState(null);
  const [schedule, setSchedule] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentTimeBlock, setCurrentTimeBlock] = useState(null);
  const [nextTimeBlock, setNextTimeBlock] = useState(null);
  const [timeStr, setTimeStr] = useState('');

  const fetchData = async () => {
    setLoading(true);
    try {
      const statsRes = await api.get('/analytics');
      setStats(statsRes.data);
      
      const dateStr = new Date().toISOString().split('T')[0];
      const scheduleRes = await api.get(`/schedules/${dateStr}`);
      setSchedule(scheduleRes.data);
    } catch (err) {
      console.warn("Failed to load dashboard data", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    const updateBlocks = () => {
      const now = new Date();
      const HH = String(now.getHours()).padStart(2, '0');
      const MM = String(now.getMinutes()).padStart(2, '0');
      const timeNow = `${HH}:${MM}`;
      setTimeStr(timeNow);
      
      if (!schedule || !schedule.timeBlocks) return;
      
      const blocks = schedule.timeBlocks;
      
      const current = blocks.find(b => b.startTime <= timeNow && b.endTime >= timeNow);
      setCurrentTimeBlock(current || null);
      
      const upcoming = blocks.find(b => b.startTime > timeNow);
      setNextTimeBlock(upcoming || null);
    };

    updateBlocks();
    const interval = setInterval(updateBlocks, 15000);
    return () => clearInterval(interval);
  }, [schedule]);

  return (
    <div className="pl-72 pr-8 py-8 min-h-screen relative">
      <div className="bg-mesh" />

      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-black text-slate-100 tracking-wider">DASHBOARD</h1>
          <p className="text-xs text-slate-500 font-semibold uppercase tracking-widest mt-0.5">Real-time execution analytics</p>
        </div>
        <button
          onClick={fetchData}
          className="p-2 border border-slate-800 hover:border-slate-700 bg-slate-900/40 hover:text-emerald-400 rounded-xl smooth-transition cursor-pointer"
          title="Reload Dashboard"
        >
          <RefreshCw className="h-4 w-4" />
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64 text-slate-500">
          Loading metrics...
        </div>
      ) : (
        <div className="space-y-6">
          <div className="glass-panel p-6 rounded-3xl border border-slate-800 bg-gradient-to-r from-emerald-950/15 via-[#111827]/75 to-transparent relative overflow-hidden flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="absolute top-0 right-0 h-40 w-40 rounded-full bg-emerald-500/5 blur-[50px] pointer-events-none" />
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded font-bold uppercase tracking-wider">
                  Active Execution
                </span>
                <span className="text-xs text-slate-500 font-mono">Clock: {timeStr}</span>
              </div>
              
              {currentTimeBlock ? (
                <div>
                  <h3 className="text-xl font-bold text-slate-100">{currentTimeBlock.title}</h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Scheduled until {currentTimeBlock.endTime} ({currentTimeBlock.type} block)
                  </p>
                </div>
              ) : (
                <div>
                  <h3 className="text-xl font-bold text-slate-400 italic">No Active Block</h3>
                  {nextTimeBlock ? (
                    <p className="text-xs text-slate-400 mt-1">
                      Next up: <span className="text-slate-200 font-semibold">{nextTimeBlock.title}</span> at {nextTimeBlock.startTime}
                    </p>
                  ) : (
                    <p className="text-xs text-slate-500 mt-1">Schedules are clear. Focus, rest, or plan new tasks!</p>
                  )}
                </div>
              )}
            </div>
            
            {currentTimeBlock && (
              <div className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/20 px-4 py-3 rounded-2xl">
                <Play className="h-4 w-4 text-emerald-400 animate-pulse" />
                <span className="text-xs font-semibold text-emerald-300 font-mono uppercase tracking-wider">Focus Active</span>
              </div>
            )}
          </div>

          {stats && <DashboardStats stats={stats} />}
        </div>
      )}
    </div>
  );
};

export default Dashboard;
