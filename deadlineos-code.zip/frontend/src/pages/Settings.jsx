import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import api from '../services/api.js';
import { Settings as SettingsIcon, Calendar, Check, AlertCircle, Loader2 } from 'lucide-react';

const Settings = () => {
  const { userData, setUserData } = useAuth();
  const location = useLocation();

  const [workStart, setWorkStart] = useState('09:00');
  const [workEnd, setWorkEnd] = useState('17:00');
  const [timezone, setTimezone] = useState('UTC');
  const [remindMinutes, setRemindMinutes] = useState('15');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (userData && userData.settings) {
      setWorkStart(userData.settings.workStart || '09:00');
      setWorkEnd(userData.settings.workEnd || '17:00');
      setTimezone(userData.settings.timezone || 'UTC');
      setRemindMinutes(String(userData.settings.notificationPreferences?.remindBeforeMinutes || 15));
    }
  }, [userData]);

  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const code = urlParams.get('code');
    
    if (code) {
      const linkCalendar = async () => {
        try {
          await api.post('/auth/google-calendar-auth', { code });
          alert("Google Calendar successfully connected!");
          const userRes = await api.post('/auth/register-or-login');
          setUserData(userRes.data.user);
        } catch (error) {
          console.error(error);
          alert("Failed to connect Google Calendar.");
        } finally {
          window.history.replaceState({}, document.title, window.location.pathname);
        }
      };
      linkCalendar();
    }
  }, [location.search, setUserData]);

  const handleConnectCalendar = () => {
    const clientId = import.meta.env.VITE_GOOGLE_CLIENT_ID || 'YOUR_GOOGLE_CLIENT_ID';
    const redirectUri = window.location.origin + '/settings';
    const scope = 'https://www.googleapis.com/auth/calendar';
    
    const oauthUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
      `client_id=${clientId}&` +
      `redirect_uri=${encodeURIComponent(redirectUri)}&` +
      `response_type=code&` +
      `scope=${encodeURIComponent(scope)}&` +
      `access_type=offline&` +
      `prompt=consent`;
      
    window.location.href = oauthUrl;
  };

  const handleSaveSettings = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const updatedSettings = {
        workStart,
        workEnd,
        timezone,
        notificationPreferences: {
          remindersEnabled: true,
          remindBeforeMinutes: parseInt(remindMinutes) || 15
        }
      };
      
      const res = await api.patch('/auth/settings', { settings: updatedSettings });
      setUserData(res.data.user);
      alert('Settings updated successfully!');
    } catch (err) {
      console.error(err);
      alert('Failed to save settings.');
    } finally {
      setSaving(false);
    }
  };

  const isCalendarConnected = userData && userData.googleCalendarTokens;

  return (
    <div className="pl-72 pr-8 py-8 min-h-screen relative">
      <div className="bg-mesh" />

      <div className="flex items-center gap-3 mb-8">
        <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 neon-glow-primary">
          <SettingsIcon className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-2xl font-black text-slate-100 tracking-wider">SETTINGS</h1>
          <p className="text-xs text-slate-500 font-semibold uppercase tracking-widest mt-0.5">Customize your AI planner and connections</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-4xl">
        <div className="lg:col-span-2 glass-panel p-6 rounded-2xl border border-slate-800">
          <h3 className="text-sm font-bold text-slate-300 mb-4 uppercase tracking-wider">Work Hours & Planner Preferences</h3>
          
          <form onSubmit={handleSaveSettings} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs text-slate-500 font-bold uppercase tracking-wider">Working Hours Start</label>
                <input
                  type="time"
                  value={workStart}
                  onChange={(e) => setWorkStart(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-900 focus:border-slate-750 text-sm text-slate-200 rounded-lg outline-none"
                  required
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs text-slate-500 font-bold uppercase tracking-wider">Working Hours End</label>
                <input
                  type="time"
                  value={workEnd}
                  onChange={(e) => setWorkEnd(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-900 focus:border-slate-750 text-sm text-slate-200 rounded-lg outline-none"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs text-slate-500 font-bold uppercase tracking-wider">Timezone</label>
                <select
                  value={timezone}
                  onChange={(e) => setTimezone(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-900 focus:border-slate-750 text-sm text-slate-200 rounded-lg outline-none"
                >
                  <option value="UTC">UTC (Coordinated Universal Time)</option>
                  <option value="America/New_York">America/New_York (EST)</option>
                  <option value="America/Chicago">America/Chicago (CST)</option>
                  <option value="America/Los_Angeles">America/Los_Angeles (PST)</option>
                  <option value="Europe/London">Europe/London (GMT)</option>
                  <option value="Asia/Kolkata">Asia/Kolkata (IST)</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-xs text-slate-500 font-bold uppercase tracking-wider">Remind Before (Minutes)</label>
                <input
                  type="number"
                  value={remindMinutes}
                  onChange={(e) => setRemindMinutes(e.target.value)}
                  placeholder="15"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-900 focus:border-slate-750 text-sm text-slate-200 rounded-lg outline-none"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-800/40 text-slate-950 font-bold text-xs rounded-lg smooth-transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              {saving ? (
                <>
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  Saving Configuration...
                </>
              ) : (
                'Save Settings'
              )}
            </button>
          </form>
        </div>

        <div className="glass-panel p-6 rounded-2xl border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="h-5 w-5 text-emerald-400 animate-pulse" />
              <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider">Integrations</h3>
            </div>
            
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              Connect Google Calendar to let DeadlineOS fetch your busy blocks and sync your daily scheduled focus blocks automatically.
            </p>

            <div className={`p-4 rounded-xl border flex items-center gap-3 ${
              isCalendarConnected 
                ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-400'
                : 'bg-slate-900 border-slate-800 text-slate-450'
            }`}>
              {isCalendarConnected ? (
                <>
                  <Check className="h-5 w-5 shrink-0" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-200">Google Calendar Connected</h4>
                    <p className="text-[10px] text-slate-500 mt-0.5">Offline sync enabled</p>
                  </div>
                </>
              ) : (
                <>
                  <AlertCircle className="h-5 w-5 shrink-0" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-400">Calendar Disconnected</h4>
                    <p className="text-[10px] text-slate-500 mt-0.5">Focus slots scheduled locally only</p>
                  </div>
                </>
              )}
            </div>
          </div>

          <button
            onClick={handleConnectCalendar}
            className={`w-full py-2.5 rounded-lg text-xs font-bold smooth-transition cursor-pointer mt-6 ${
              isCalendarConnected
                ? 'bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700/60'
                : 'bg-emerald-500 hover:bg-emerald-600 text-slate-950'
            }`}
          >
            {isCalendarConnected ? 'Reconnect Calendar' : 'Connect Google Calendar'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Settings;
