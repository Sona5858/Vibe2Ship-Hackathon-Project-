import React, { useState, useEffect } from 'react';
import api from '../services/api.js';
import TaskList from '../components/TaskList.jsx';
import ImageUpload from '../components/ImageUpload.jsx';
import VoiceInput from '../components/VoiceInput.jsx';
import { Plus, Loader2, ListTodo } from 'lucide-react';

const Tasks = () => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // Manual Form States
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [deadline, setDeadline] = useState('');
  const [duration, setDuration] = useState('45');

  const fetchTasks = async () => {
    try {
      const res = await api.get('/tasks');
      setTasks(res.data);
    } catch (err) {
      console.error("Failed to load tasks", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const handleManualSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;

    setSubmitting(true);
    try {
      const res = await api.post('/tasks', {
        title,
        description,
        deadline: deadline ? new Date(deadline).toISOString() : null,
        estimatedDuration: parseInt(duration) || 45
      });
      setTasks(prev => [res.data, ...prev]);
      setTitle('');
      setDescription('');
      setDeadline('');
      setDuration('45');
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleStatusChange = async (id, status) => {
    try {
      const res = await api.patch(`/tasks/${id}`, { status });
      setTasks(tasks.map(t => (t.id === id ? res.data : t)));
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this task?')) return;
    try {
      await api.delete(`/tasks/${id}`);
      setTasks(tasks.filter(t => t.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  const handleImageExtract = async (file) => {
    const formData = new FormData();
    formData.append('image', file);
    const res = await api.post('/tasks/extract', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
    setTasks(prev => [...res.data.tasks, ...prev]);
  };

  const handleVoiceSubmit = async (transcript) => {
    const res = await api.post('/tasks/extract', { textPrompt: transcript });
    setTasks(prev => [...res.data.tasks, ...prev]);
  };

  return (
    <div className="pl-72 pr-8 py-8 min-h-screen relative">
      <div className="bg-mesh" />

      <div className="flex items-center gap-3 mb-8">
        <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 neon-glow-primary">
          <ListTodo className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-2xl font-black text-slate-100 tracking-wider">TASK HUB</h1>
          <p className="text-xs text-slate-500 font-semibold uppercase tracking-widest mt-0.5">Manage tasks and prioritize with AI</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64 text-slate-500">
          Loading tasks...
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <div className="lg:col-span-3 space-y-6">
            <div className="glass-panel p-6 rounded-2xl border border-slate-800">
              <h3 className="text-sm font-bold text-slate-300 mb-4 uppercase tracking-wider">Manual Task Input</h3>
              
              <form onSubmit={handleManualSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs text-slate-500 font-bold uppercase tracking-wider">Title</label>
                    <input
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="e.g., File expense report"
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-900 focus:border-slate-750 text-sm text-slate-200 rounded-lg outline-none"
                      required
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-slate-500 font-bold uppercase tracking-wider">Deadline</label>
                    <input
                      type="datetime-local"
                      value={deadline}
                      onChange={(e) => setDeadline(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-900 focus:border-slate-750 text-sm text-slate-200 rounded-lg outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs text-slate-500 font-bold uppercase tracking-wider">Description</label>
                    <input
                      type="text"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Optional notes or details"
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-900 focus:border-slate-750 text-sm text-slate-200 rounded-lg outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-slate-500 font-bold uppercase tracking-wider">Duration (Minutes)</label>
                    <input
                      type="number"
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      placeholder="45"
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-900 focus:border-slate-750 text-sm text-slate-200 rounded-lg outline-none"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-800/40 text-slate-950 font-bold text-xs rounded-lg smooth-transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <Plus className="h-4 w-4" />
                      Create & Score Priority
                    </>
                  )}
                </button>
              </form>
            </div>

            <div className="glass-panel p-6 rounded-2xl border border-slate-800">
              <TaskList
                tasks={tasks}
                onStatusChange={handleStatusChange}
                onDelete={handleDelete}
              />
            </div>
          </div>

          <div className="lg:col-span-2 space-y-6">
            <VoiceInput onVoiceSubmit={handleVoiceSubmit} />
            <ImageUpload onExtract={handleImageExtract} />
          </div>
        </div>
      )}
    </div>
  );
};

export default Tasks;
