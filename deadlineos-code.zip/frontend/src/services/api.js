import axios from 'axios';
import { auth } from './firebase.js';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5001/api',
});

api.interceptors.request.use(async (config) => {
  const user = auth.currentUser;
  if (user) {
    try {
      const token = await user.getIdToken(true); // force refresh if necessary
      config.headers.Authorization = `Bearer ${token}`;
    } catch (err) {
      console.error("Error setting ID token in request headers:", err);
    }
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

export default api;
