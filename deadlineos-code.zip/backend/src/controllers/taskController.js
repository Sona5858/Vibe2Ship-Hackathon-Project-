import { db } from '../config/firebase.js';
import { genAI } from '../config/gemini.js';
import { PRIORITY_SCORING_PROMPT, TASK_EXTRACTION_PROMPT } from '../utils/promptTemplates.js';

export const calculatePriorityScore = async (taskDetails, pendingCount) => {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
    const prompt = PRIORITY_SCORING_PROMPT
      .replace('{title}', taskDetails.title)
      .replace('{description}', taskDetails.description || 'None')
      .replace('{deadline}', taskDetails.deadline || 'No deadline')
      .replace('{estimatedDuration}', taskDetails.estimatedDuration || 45)
      .replace('{currentTime}', new Date().toISOString())
      .replace('{pendingCount}', pendingCount);

    const result = await model.generateContent({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: { responseMimeType: "application/json" }
    });

    const responseText = result.response.text();
    const data = JSON.parse(responseText);
    return {
      priorityScore: data.priorityScore || 50,
      priorityExplanation: data.priorityExplanation || "Calculated using task details."
    };
  } catch (error) {
    console.error("Error calculating priority score:", error);
    return {
      priorityScore: 50,
      priorityExplanation: "Failed to calculate priority using AI, defaulted to 50."
    };
  }
};

function fileToGenerativePart(buffer, mimeType) {
  return {
    inlineData: {
      data: buffer.toString("base64"),
      mimeType
    },
  };
}

export const extractTasks = async (req, res) => {
  const { uid } = req.user;
  const { textPrompt } = req.body;
  const file = req.file;
  
  if (!textPrompt && !file) {
    return res.status(400).json({ error: "Please provide a text description or an image upload." });
  }
  
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
    const parts = [];
    
    parts.push({ text: TASK_EXTRACTION_PROMPT });
    
    if (textPrompt) {
      parts.push({ text: `User input: "${textPrompt}"` });
    }
    
    if (file) {
      parts.push(fileToGenerativePart(file.buffer, file.mimetype));
    }
    
    const result = await model.generateContent({
      contents: [{ role: "user", parts }],
      generationConfig: { responseMimeType: "application/json" }
    });
    
    const responseText = result.response.text();
    const parsedData = JSON.parse(responseText);
    
    if (!parsedData.tasks || !Array.isArray(parsedData.tasks)) {
      throw new Error("Invalid response format from Gemini");
    }
    
    const pendingTasksSnapshot = await db.collection('tasks')
      .where('userId', '==', uid)
      .where('status', '==', 'pending')
      .get();
    const pendingCount = pendingTasksSnapshot.size;
    
    const createdTasks = [];
    const tasksCollection = db.collection('tasks');
    
    for (const extractedTask of parsedData.tasks) {
      const scoreResult = await calculatePriorityScore(extractedTask, pendingCount + createdTasks.length);
      
      const taskDocRef = tasksCollection.doc();
      const taskData = {
        id: taskDocRef.id,
        userId: uid,
        title: extractedTask.title,
        description: extractedTask.description || '',
        deadline: extractedTask.deadline ? new Date(extractedTask.deadline).toISOString() : null,
        estimatedDuration: extractedTask.estimatedDuration || 45,
        priorityScore: scoreResult.priorityScore,
        priorityExplanation: scoreResult.priorityExplanation,
        status: 'pending',
        skippedCount: 0,
        source: file ? 'image' : 'text',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      await taskDocRef.set(taskData);
      createdTasks.push(taskData);
    }
    
    return res.status(200).json({
      message: `Successfully extracted and saved ${createdTasks.length} tasks.`,
      tasks: createdTasks
    });
  } catch (error) {
    console.error("Error in extractTasks:", error);
    return res.status(500).json({ error: "Failed to extract tasks using AI." });
  }
};

export const getTasks = async (req, res) => {
  const { uid } = req.user;
  try {
    const snapshot = await db.collection('tasks')
      .where('userId', '==', uid)
      .get();
      
    const tasks = [];
    snapshot.forEach(doc => {
      tasks.push(doc.data());
    });
    
    // Sort manually by creation date in memory, or use indexes.
    tasks.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    return res.status(200).json(tasks);
  } catch (error) {
    console.error('Error fetching tasks:', error);
    return res.status(500).json({ error: 'Failed to fetch tasks' });
  }
};

export const createTask = async (req, res) => {
  const { uid } = req.user;
  const { title, description, deadline, estimatedDuration } = req.body;
  
  if (!title) {
    return res.status(400).json({ error: 'Title is required' });
  }
  
  try {
    const pendingTasksSnapshot = await db.collection('tasks')
      .where('userId', '==', uid)
      .where('status', '==', 'pending')
      .get();
    const pendingCount = pendingTasksSnapshot.size;
    
    const taskDetails = {
      title,
      description: description || '',
      deadline: deadline || null,
      estimatedDuration: parseInt(estimatedDuration) || 45
    };
    
    const scoreResult = await calculatePriorityScore(taskDetails, pendingCount);
    
    const taskDocRef = db.collection('tasks').doc();
    const newTask = {
      id: taskDocRef.id,
      userId: uid,
      ...taskDetails,
      priorityScore: scoreResult.priorityScore,
      priorityExplanation: scoreResult.priorityExplanation,
      status: 'pending',
      skippedCount: 0,
      source: 'manual',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    await taskDocRef.set(newTask);
    return res.status(201).json(newTask);
  } catch (error) {
    console.error('Error creating task:', error);
    return res.status(500).json({ error: 'Failed to create task' });
  }
};

export const updateTask = async (req, res) => {
  const { uid } = req.user;
  const { id } = req.params;
  const updates = req.body;
  
  try {
    const taskRef = db.collection('tasks').doc(id);
    const taskDoc = await taskRef.get();
    
    if (!taskDoc.exists || taskDoc.data().userId !== uid) {
      return res.status(404).json({ error: 'Task not found' });
    }
    
    if (updates.status === 'skipped' && taskDoc.data().status !== 'skipped') {
      updates.skippedCount = (taskDoc.data().skippedCount || 0) + 1;
    }
    
    updates.updatedAt = new Date().toISOString();
    
    await taskRef.update(updates);
    
    const updatedDoc = await taskRef.get();
    return res.status(200).json(updatedDoc.data());
  } catch (error) {
    console.error('Error updating task:', error);
    return res.status(500).json({ error: 'Failed to update task' });
  }
};

export const deleteTask = async (req, res) => {
  const { uid } = req.user;
  const { id } = req.params;
  
  try {
    const taskRef = db.collection('tasks').doc(id);
    const taskDoc = await taskRef.get();
    
    if (!taskDoc.exists || taskDoc.data().userId !== uid) {
      return res.status(404).json({ error: 'Task not found' });
    }
    
    await taskRef.delete();
    return res.status(200).json({ message: 'Task deleted successfully' });
  } catch (error) {
    console.error('Error deleting task:', error);
    return res.status(500).json({ error: 'Failed to delete task' });
  }
};
