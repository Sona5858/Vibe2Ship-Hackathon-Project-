import { db } from '../config/firebase.js';
import { genAI } from '../config/gemini.js';
import { google } from '../config/googleCalendar.js';
import { SCHEDULING_PROMPT } from '../utils/promptTemplates.js';

const getCalendarClient = (tokens) => {
  const auth = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI || 'postmessage'
  );
  auth.setCredentials(tokens);
  return google.calendar({ version: 'v3', auth });
};

const fetchBusySlots = async (calendar, timezone, dateStr) => {
  // Use dates in user's timezone bounds
  const startOfDay = new Date(`${dateStr}T00:00:00Z`).toISOString();
  const endOfDay = new Date(`${dateStr}T23:59:59Z`).toISOString();
  
  try {
    const res = await calendar.events.list({
      calendarId: 'primary',
      timeMin: startOfDay,
      timeMax: endOfDay,
      singleEvents: true,
      orderBy: 'startTime',
      timeZone: timezone || 'UTC'
    });
    
    const events = res.data.items || [];
    return events.map(event => {
      const start = event.start.dateTime || event.start.date;
      const end = event.end.dateTime || event.end.date;
      
      const startLocal = new Date(start).toLocaleTimeString('en-US', { 
        hour12: false, 
        hour: '2-digit', 
        minute: '2-digit', 
        timeZone: timezone || 'UTC' 
      });
      const endLocal = new Date(end).toLocaleTimeString('en-US', { 
        hour12: false, 
        hour: '2-digit', 
        minute: '2-digit', 
        timeZone: timezone || 'UTC' 
      });
      
      return {
        title: event.summary || 'Busy Slot',
        startTime: startLocal,
        endTime: endLocal
      };
    });
  } catch (error) {
    console.error('Error fetching calendar events:', error);
    return [];
  }
};

const getOrCreateDeadlineOSCalendar = async (calendar, timezone) => {
  try {
    const listRes = await calendar.calendarList.list();
    const existing = (listRes.data.items || []).find(item => item.summary === 'DeadlineOS');
    
    if (existing) {
      return existing.id;
    }
    
    const createRes = await calendar.calendars.insert({
      requestBody: {
        summary: 'DeadlineOS',
        description: 'DeadlineOS AI Execution Agent Generated Focus Blocks',
        timeZone: timezone || 'UTC'
      }
    });
    return createRes.data.id;
  } catch (error) {
    console.error('Error getting/creating DeadlineOS calendar:', error);
    throw error;
  }
};

export const getSchedule = async (req, res) => {
  const { uid } = req.user;
  const { date } = req.params; // Expect YYYY-MM-DD
  
  if (!date) {
    return res.status(400).json({ error: 'Date is required' });
  }
  
  try {
    const docId = `${uid}_${date}`;
    const scheduleDoc = await db.collection('schedules').doc(docId).get();
    
    if (!scheduleDoc.exists) {
      return res.status(404).json({ message: 'No schedule found for this date', timeBlocks: [] });
    }
    
    return res.status(200).json(scheduleDoc.data());
  } catch (error) {
    console.error('Error fetching schedule:', error);
    return res.status(500).json({ error: 'Failed to fetch schedule' });
  }
};

export const generateSchedule = async (req, res) => {
  const { uid } = req.user;
  const { date } = req.body; // YYYY-MM-DD
  
  if (!date) {
    return res.status(400).json({ error: 'Date is required' });
  }
  
  try {
    // 1. Fetch User Settings
    const userDoc = await db.collection('users').doc(uid).get();
    if (!userDoc.exists) {
      return res.status(404).json({ error: 'User profile not found' });
    }
    const userData = userDoc.data();
    const settings = userData.settings || { workStart: '09:00', workEnd: '17:00', timezone: 'UTC' };
    
    // 2. Fetch Busy Slots from Google Calendar if connected
    let busySlots = [];
    let calendarConnected = false;
    if (userData.googleCalendarTokens) {
      try {
        const calendarClient = getCalendarClient(userData.googleCalendarTokens);
        busySlots = await fetchBusySlots(calendarClient, settings.timezone, date);
        calendarConnected = true;
      } catch (calError) {
        console.warn('Failed to access Google Calendar, proceeding without busy slots:', calError);
      }
    }
    
    // 3. Fetch Pending Tasks
    const tasksSnapshot = await db.collection('tasks')
      .where('userId', '==', uid)
      .where('status', '==', 'pending')
      .get();
      
    const tasks = [];
    tasksSnapshot.forEach(doc => {
      tasks.push(doc.data());
    });
    
    if (tasks.length === 0) {
      return res.status(200).json({ 
        message: 'No pending tasks to schedule. Create some tasks first!', 
        timeBlocks: [] 
      });
    }
    
    // Sort tasks in memory by priority score descending
    tasks.sort((a, b) => b.priorityScore - a.priorityScore);
    
    // 4. Generate Schedule via Gemini 2.5 Flash
    const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });
    const prompt = SCHEDULING_PROMPT
      .replace('{workStart}', settings.workStart)
      .replace('{workEnd}', settings.workEnd)
      .replace('{busySlots}', JSON.stringify(busySlots))
      .replace('{tasksJson}', JSON.stringify(tasks))
      .replace('{timezone}', settings.timezone || 'UTC')
      .replace('{currentDate}', date);
      
    const aiResult = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: { responseMimeType: 'application/json' }
    });
    
    const responseText = aiResult.response.text();
    const parsedSchedule = JSON.parse(responseText);
    
    // Add unique IDs to the generated timeblocks
    const timeBlocks = (parsedSchedule.timeBlocks || []).map((block, idx) => ({
      id: `${uid}_${date}_tb_${idx}_${Date.now()}`,
      status: 'pending',
      ...block
    }));
    
    const scheduleData = {
      id: `${uid}_${date}`,
      userId: uid,
      date,
      timeBlocks,
      reasoning: parsedSchedule.reasoning || '',
      calendarSynced: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    await db.collection('schedules').doc(scheduleData.id).set(scheduleData);
    
    return res.status(200).json(scheduleData);
  } catch (error) {
    console.error('Error generating schedule:', error);
    return res.status(500).json({ error: 'Failed to generate schedule' });
  }
};

export const replanSchedule = async (req, res) => {
  const { uid } = req.user;
  const { date, currentTime } = req.body; // date: YYYY-MM-DD, currentTime: HH:mm
  
  if (!date || !currentTime) {
    return res.status(400).json({ error: 'Date and current time (HH:mm) are required' });
  }
  
  try {
    const docId = `${uid}_${date}`;
    const scheduleDoc = await db.collection('schedules').doc(docId).get();
    
    if (!scheduleDoc.exists) {
      return res.status(404).json({ error: 'No schedule exists to replan. Generate one first.' });
    }
    
    const existingSchedule = scheduleDoc.data();
    const userDoc = await db.collection('users').doc(uid).get();
    const userData = userDoc.data();
    const settings = userData.settings || { workStart: '09:00', workEnd: '17:00', timezone: 'UTC' };
    
    // We want to preserve completed blocks before current time
    // And reschedule pending/skipped blocks and tasks from currentTime onwards
    const completedBlocks = existingSchedule.timeBlocks.filter(block => 
      block.status === 'completed' || block.endTime <= currentTime
    );
    
    // Get all pending tasks
    const tasksSnapshot = await db.collection('tasks')
      .where('userId', '==', uid)
      .where('status', '==', 'pending')
      .get();
      
    const tasks = [];
    tasksSnapshot.forEach(doc => {
      tasks.push(doc.data());
    });
    
    tasks.sort((a, b) => b.priorityScore - a.priorityScore);
    
    // Fetch updated busy slots from Google Calendar starting from current time
    let busySlots = [];
    if (userData.googleCalendarTokens) {
      try {
        const calendarClient = getCalendarClient(userData.googleCalendarTokens);
        const allBusy = await fetchBusySlots(calendarClient, settings.timezone, date);
        // filter for busy slots after current time
        busySlots = allBusy.filter(slot => slot.endTime > currentTime);
      } catch (calError) {
        console.warn('Google Calendar sync failed in replan, proceeding without calendar events:', calError);
      }
    }
    
    // Generate new schedule starting from currentTime to workEnd
    const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });
    const prompt = SCHEDULING_PROMPT
      .replace('{workStart}', currentTime) // replanning starts now!
      .replace('{workEnd}', settings.workEnd)
      .replace('{busySlots}', JSON.stringify(busySlots))
      .replace('{tasksJson}', JSON.stringify(tasks))
      .replace('{timezone}', settings.timezone || 'UTC')
      .replace('{currentDate}', date);
      
    const aiResult = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: { responseMimeType: 'application/json' }
    });
    
    const responseText = aiResult.response.text();
    const parsedSchedule = JSON.parse(responseText);
    
    const newTimeBlocks = (parsedSchedule.timeBlocks || []).map((block, idx) => ({
      id: `${uid}_${date}_repl_${idx}_${Date.now()}`,
      status: 'pending',
      ...block
    }));
    
    // Merge preservation and new scheduling
    const mergedBlocks = [...completedBlocks, ...newTimeBlocks];
    
    // Sort merged blocks by startTime
    mergedBlocks.sort((a, b) => a.startTime.localeCompare(b.startTime));
    
    const updatedSchedule = {
      ...existingSchedule,
      timeBlocks: mergedBlocks,
      reasoning: `Replanned at ${currentTime}. ${parsedSchedule.reasoning || ''}`,
      calendarSynced: false,
      updatedAt: new Date().toISOString()
    };
    
    await db.collection('schedules').doc(docId).set(updatedSchedule);
    
    return res.status(200).json(updatedSchedule);
  } catch (error) {
    console.error('Error in replanSchedule:', error);
    return res.status(500).json({ error: 'Failed to replan schedule' });
  }
};

export const syncScheduleToGoogleCalendar = async (req, res) => {
  const { uid } = req.user;
  const { date } = req.body; // YYYY-MM-DD
  
  if (!date) {
    return res.status(400).json({ error: 'Date is required' });
  }
  
  try {
    const docId = `${uid}_${date}`;
    const scheduleDoc = await db.collection('schedules').doc(docId).get();
    
    if (!scheduleDoc.exists) {
      return res.status(404).json({ error: 'No schedule found for this date to sync.' });
    }
    
    const schedule = scheduleDoc.data();
    const userDoc = await db.collection('users').doc(uid).get();
    const userData = userDoc.data();
    
    if (!userData.googleCalendarTokens) {
      return res.status(400).json({ error: 'Google Calendar is not linked. Connect it in settings.' });
    }
    
    const settings = userData.settings || { timezone: 'UTC' };
    const calendarClient = getCalendarClient(userData.googleCalendarTokens);
    
    // Get or Create dedicated calendar
    const calendarId = await getOrCreateDeadlineOSCalendar(calendarClient, settings.timezone);
    
    // Clear existing events for this day in DeadlineOS calendar to prevent duplicates
    const startOfDay = new Date(`${date}T00:00:00Z`).toISOString();
    const endOfDay = new Date(`${date}T23:59:59Z`).toISOString();
    
    const existingEventsRes = await calendarClient.events.list({
      calendarId,
      timeMin: startOfDay,
      timeMax: endOfDay,
      singleEvents: true
    });
    
    const existingEvents = existingEventsRes.data.items || [];
    for (const ev of existingEvents) {
      await calendarClient.events.delete({
        calendarId,
        eventId: ev.id
      });
    }
    
    // Add new focus blocks
    const focusBlocks = schedule.timeBlocks.filter(block => block.type === 'focus');
    for (const block of focusBlocks) {
      const event = {
        summary: block.title,
        description: `DeadlineOS Scheduled Focus Block`,
        start: {
          dateTime: `${date}T${block.startTime}:00`,
          timeZone: settings.timezone || 'UTC',
        },
        end: {
          dateTime: `${date}T${block.endTime}:00`,
          timeZone: settings.timezone || 'UTC',
        },
        reminders: {
          useDefault: false,
          overrides: [
            { method: 'popup', minutes: settings.notificationPreferences?.remindBeforeMinutes || 15 }
          ]
        }
      };
      
      await calendarClient.events.insert({
        calendarId,
        requestBody: event
      });
    }
    
    await db.collection('schedules').doc(docId).update({
      calendarSynced: true,
      updatedAt: new Date().toISOString()
    });
    
    return res.status(200).json({ message: `Successfully synced ${focusBlocks.length} focus blocks to Google Calendar!` });
  } catch (error) {
    console.error('Error syncing to Google Calendar:', error);
    return res.status(500).json({ error: 'Failed to sync schedule with Google Calendar' });
  }
};

export const updateBlockStatus = async (req, res) => {
  const { uid } = req.user;
  const { date, blockId } = req.params;
  const { status } = req.body;
  
  if (!date || !blockId || !status) {
    return res.status(400).json({ error: 'Date, blockId, and status are required' });
  }
  
  try {
    const docId = `${uid}_${date}`;
    const scheduleRef = db.collection('schedules').doc(docId);
    const scheduleDoc = await scheduleRef.get();
    
    if (!scheduleDoc.exists) {
      return res.status(404).json({ error: 'Schedule not found' });
    }
    
    const scheduleData = scheduleDoc.data();
    const updatedBlocks = scheduleData.timeBlocks.map(block => {
      if (block.id === blockId) {
        return { ...block, status };
      }
      return block;
    });
    
    await scheduleRef.update({
      timeBlocks: updatedBlocks,
      updatedAt: new Date().toISOString()
    });
    
    const updatedDoc = await scheduleRef.get();
    return res.status(200).json(updatedDoc.data());
  } catch (error) {
    console.error('Error updating block status:', error);
    return res.status(500).json({ error: 'Failed to update block status' });
  }
};

