import { db } from '../config/firebase.js';
import { oauth2Client } from '../config/googleCalendar.js';

export const registerOrLogin = async (req, res) => {
  const { uid, email, name, picture } = req.user;
  
  try {
    const userRef = db.collection('users').doc(uid);
    const userDoc = await userRef.get();
    
    if (!userDoc.exists) {
      const defaultSettings = {
        workStart: '09:00',
        workEnd: '17:00',
        timezone: 'UTC',
        notificationPreferences: {
          remindersEnabled: true,
          remindBeforeMinutes: 15
        }
      };
      
      const userData = {
        uid,
        email,
        displayName: name || '',
        photoURL: picture || '',
        settings: defaultSettings,
        createdAt: new Date().toISOString()
      };
      
      await userRef.set(userData);
      console.log(`New user registered: ${email}`);
      return res.status(200).json({ user: userData });
    } else {
      const updateData = {
        displayName: name || '',
        photoURL: picture || ''
      };
      await userRef.update(updateData);
      console.log(`User logged in: ${email}`);
      
      const updatedDoc = await userRef.get();
      return res.status(200).json({ user: updatedDoc.data() });
    }
  } catch (error) {
    console.error('Error in registerOrLogin:', error);
    return res.status(500).json({ error: 'Failed to sync user data' });
  }
};

export const linkGoogleCalendar = async (req, res) => {
  const { uid } = req.user;
  const { code } = req.body;
  
  if (!code) {
    return res.status(400).json({ error: 'OAuth code is required' });
  }
  
  try {
    const { tokens } = await oauth2Client.getToken(code);
    
    // Save tokens in user document
    const userRef = db.collection('users').doc(uid);
    await userRef.update({
      googleCalendarTokens: tokens,
      updatedAt: new Date().toISOString()
    });
    
    return res.status(200).json({ message: 'Google Calendar successfully connected!' });
  } catch (error) {
    console.error('Error exchanging Google OAuth code:', error);
    return res.status(500).json({ error: 'Failed to link Google Calendar' });
  }
};

export const updateSettings = async (req, res) => {
  const { uid } = req.user;
  const { settings } = req.body;
  
  if (!settings) {
    return res.status(400).json({ error: 'Settings are required' });
  }
  
  try {
    const userRef = db.collection('users').doc(uid);
    await userRef.update({
      settings,
      updatedAt: new Date().toISOString()
    });
    
    const updatedDoc = await userRef.get();
    return res.status(200).json({ user: updatedDoc.data() });
  } catch (error) {
    console.error('Error updating settings:', error);
    return res.status(500).json({ error: 'Failed to update settings' });
  }
};

