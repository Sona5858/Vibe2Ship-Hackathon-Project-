import { db } from '../config/firebase.js';
import { genAI } from '../config/gemini.js';
import { COACHING_PROMPT } from '../utils/promptTemplates.js';

export const getAnalytics = async (req, res) => {
  const { uid } = req.user;
  
  try {
    const tasksSnapshot = await db.collection('tasks')
      .where('userId', '==', uid)
      .get();
      
    let tasksCompleted = 0;
    let tasksSkipped = 0;
    let tasksPending = 0;
    let totalFocusMinutes = 0;
    
    tasksSnapshot.forEach(doc => {
      const task = doc.data();
      if (task.status === 'completed') {
        tasksCompleted++;
        totalFocusMinutes += parseInt(task.estimatedDuration) || 45;
      } else if (task.status === 'skipped') {
        tasksSkipped++;
      } else if (task.status === 'pending') {
        tasksPending++;
      }
    });
    
    const totalTasks = tasksCompleted + tasksSkipped;
    const completionRate = totalTasks > 0 ? Math.round((tasksCompleted / totalTasks) * 100) : 0;
    
    let insights = [
      "Add deadlines to tasks so our AI agent can schedule them automatically.",
      "Try to minimize skipped blocks to build consistent focus habits.",
      "Check your dashboard regularly for updated execution insights."
    ];
    
    try {
      const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });
      const prompt = COACHING_PROMPT
        .replace('{tasksCompleted}', tasksCompleted)
        .replace('{tasksSkipped}', tasksSkipped)
        .replace('{focusMinutes}', totalFocusMinutes)
        .replace('{completionRate}', completionRate);
        
      const aiResult = await model.generateContent({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: 'application/json' }
      });
      
      const responseText = aiResult.response.text();
      const parsedData = JSON.parse(responseText);
      if (parsedData.insights && Array.isArray(parsedData.insights)) {
        insights = parsedData.insights;
      }
    } catch (aiError) {
      console.warn("AI coaching insights generation failed, using defaults:", aiError);
    }
    
    const analyticsData = {
      userId: uid,
      completionRate,
      tasksCompleted,
      tasksSkipped,
      tasksPending,
      focusMinutes: totalFocusMinutes,
      insights,
      updatedAt: new Date().toISOString()
    };
    
    await db.collection('analytics').doc(uid).set(analyticsData);
    
    return res.status(200).json(analyticsData);
  } catch (error) {
    console.error('Error generating analytics:', error);
    return res.status(500).json({ error: 'Failed to generate analytics' });
  }
};
