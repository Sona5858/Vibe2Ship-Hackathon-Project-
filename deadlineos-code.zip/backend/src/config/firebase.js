import admin from 'firebase-admin';
import dotenv from 'dotenv';

dotenv.config();

if (!admin.apps.length) {
  try {
    admin.initializeApp({
      credential: admin.credential.applicationDefault()
    });
    console.log("Firebase Admin SDK initialized successfully via Application Default Credentials.");
  } catch (error) {
    const projectId = process.env.FIREBASE_PROJECT_ID || process.env.GCLOUD_PROJECT;
    if (projectId) {
      admin.initializeApp({
        projectId: projectId
      });
      console.log(`Firebase Admin SDK initialized with project ID: ${projectId}`);
    } else {
      admin.initializeApp({
        projectId: 'deadlineos-dev'
      });
      console.log("Firebase Admin SDK initialized with local fallback project ID (deadlineos-dev).");
    }
  }
}

const db = admin.firestore();
const auth = admin.auth();
const messaging = admin.messaging();

export { db, auth, messaging, admin };
