import express from 'express';
import { registerOrLogin, linkGoogleCalendar, updateSettings } from '../controllers/authController.js';
import { verifyToken } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/register-or-login', verifyToken, registerOrLogin);
router.post('/google-calendar-auth', verifyToken, linkGoogleCalendar);
router.patch('/settings', verifyToken, updateSettings);

export default router;
