import express from 'express';
import multer from 'multer';
import { getTasks, createTask, updateTask, deleteTask, extractTasks } from '../controllers/taskController.js';
import { verifyToken } from '../middleware/authMiddleware.js';

const router = express.Router();
const upload = multer({ limits: { fileSize: 5 * 1024 * 1024 } }); // limit to 5MB

router.get('/', verifyToken, getTasks);
router.post('/', verifyToken, createTask);
router.patch('/:id', verifyToken, updateTask);
router.delete('/:id', verifyToken, deleteTask);
router.post('/extract', verifyToken, upload.single('image'), extractTasks);

export default router;
