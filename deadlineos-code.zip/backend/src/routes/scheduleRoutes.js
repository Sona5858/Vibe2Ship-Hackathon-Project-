import express from 'express';
import { getSchedule, generateSchedule, replanSchedule, syncScheduleToGoogleCalendar, updateBlockStatus } from '../controllers/scheduleController.js';
import { verifyToken } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/:date', verifyToken, getSchedule);
router.post('/generate', verifyToken, generateSchedule);
router.post('/replan', verifyToken, replanSchedule);
router.post('/sync-calendar', verifyToken, syncScheduleToGoogleCalendar);
router.patch('/:date/blocks/:blockId', verifyToken, updateBlockStatus);

export default router;
